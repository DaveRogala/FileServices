﻿using Microsoft.EntityFrameworkCore;

namespace FileServices.Data
{
    internal class FileContext : DbContext
    {
    }
}
