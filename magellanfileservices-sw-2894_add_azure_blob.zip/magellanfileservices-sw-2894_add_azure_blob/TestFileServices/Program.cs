﻿using MagellanFileServices.Contracts;
using MagellanFileServices.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Text;
using TestFileServices.Models.DTOs;

HostApplicationBuilder builder = Host.CreateApplicationBuilder(args);

builder.Services.AddSingleton<IFileServices, FileServices>();
using IHost host = builder.Build();
IFileServices fileServices = host.Services.GetRequiredService<IFileServices>();
string basePath = "C:\\Users\\TDEV6F9\\Documents\\Transfer\\In\\M4G";

var accounts = fileServices.GetDataFromFile<AccountDTO>(Path.Combine(basePath, "Account_Test.csv"));

Console.WriteLine("Hello");