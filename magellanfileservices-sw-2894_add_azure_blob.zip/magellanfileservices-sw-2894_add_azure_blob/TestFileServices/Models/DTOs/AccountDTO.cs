﻿namespace TestFileServices.Models.DTOs
{
    internal record AccountDTO
    {
        public required string UniqueName { get; set; }
        public required string Name { get; set; }

    }
}
